<template>
  <div class="container-fluid py-5" style="
      background-color:#faf8f5;

      /* 브랜드 색상 세트 */
      --bs-primary:#6f5034;
      --bs-primary-rgb:111,80,52;

      /* 링크, 글자 */
      --bs-link-color:#6f5034;
      --bs-link-hover-color:#5b432c;

      /* 뱃지/페이지네이션 공용 */
      --bs-pagination-color:#6f5034;
      --bs-pagination-hover-color:#5b432c;
      --bs-pagination-active-bg:#6f5034;
      --bs-pagination-active-border-color:#6f5034;
    ">
    <div class="container">

      <div class="row g-4">
        <!-- ===== 왼쪽: 대표 이미지 미리보기 ===== -->
        <div class="col-md-4">
          <div class="border rounded p-3 text-center">
            <img v-if="previewImage" :src="previewImage" class="img-fluid rounded" alt="대표 미리보기" />
            <div v-else class="text-muted small">이미지 미리보기</div>
          </div>
        </div>

        <!-- ===== 중앙: 글 작성 ===== -->
        <div class="col-md-5">
          <div class="card shadow-sm">
            <div class="card-body">
              <h5 class="card-title">게시글 작성</h5>

              <!-- 제목 -->
              <input v-model="title" type="text" class="form-control mb-2" placeholder="제목을 입력하세요" />

              <!-- 내용 -->
              <textarea v-model="content" rows="6" class="form-control mb-3" placeholder="내용을 입력하세요"></textarea>

              <!-- 산책 모집글 여부 -->
              <div class="form-check mb-3">
                <input id="isRequest" class="form-check-input" type="checkbox" v-model="isRequest" />
                <label class="form-check-label" for="isRequest">산책 모집글</label>
              </div>

              <!-- 선택된 태그 보여주기 -->
              <div class="mb-3">
                <span v-for="tagId in selectedTags" :key="tagId" class="badge bg-primary me-2" style="cursor:pointer"
                  @click="removeTag(tagId)">
                  {{tags.find(t => t.tagId === tagId)?.tagName}} ✕
                </span>
              </div>

              <!-- 태그 선택 버튼 -->
              <h6 class="fw-bold">태그 선택</h6>
              <div class="d-flex flex-wrap gap-2 mb-2">
                <button v-for="(t, i) in topTags" :key="`top-${i}`" class="btn btn-sm"
                  :class="selectedTags.includes(t.tagName) ? 'btn-secondary' : 'btn-outline-primary'"
                  @click="toggleTag(t.tagName)">
                  {{ t.tagName }}
                </button>
              </div>

              <!-- collapse 안에 숨겨진 태그 -->
              <div class="collapse" id="moreTags">
                <div class="d-flex flex-wrap gap-2 mt-2">
                  <button v-for="(t, i) in moreTags" :key="`more-${i}`" class="btn btn-sm"
                    :class="selectedTags.includes(t.tagName) ? 'btn-secondary' : 'btn-outline-primary'"
                    @click="toggleTag(t.tagName)">
                    {{ t.tagName }}
                  </button>
                </div>
              </div>

              <!-- 더보기/접기 버튼 -->
              <button class="btn btn-link p-0 mt-2" type="button" data-bs-toggle="collapse" data-bs-target="#moreTags"
                aria-expanded="false" aria-controls="moreTags" @click="toggleMore">
                {{ showMore ? "접기 ▲" : "더보기 ▼" }}
              </button>

            </div>

            <div class="card-footer d-flex justify-content-between">
              <!-- 파일 업로드 -->
              <label class="btn btn-dark d-inline-flex align-items-center gap-2 mb-0">
                <i class="bi bi-folder-plus"></i>
                이미지 선택
                <input type="file" class="d-none" multiple accept="image/*" @change="onFileChange" />
              </label>

              <button type="button" class="btn btn-primary" :disabled="submitting" @click="submitPost" style="
                --bs-btn-bg:#6f5034;
                --bs-btn-border-color:#6f5034;
                --bs-btn-hover-bg:#5b432c;
                --bs-btn-hover-border-color:#5b432c;
                --bs-btn-active-bg:#4d3826;
                --bs-btn-active-border-color:#4d3826;
                --bs-btn-active-color:#fff;
                --bs-btn-focus-shadow-rgb:111,80,52;
              ">
                {{ submitting ? "등록 중..." : "게시" }}
              </button>
            </div>
          </div>
        </div>

        <!-- ===== 오른쪽: 첨부 이미지 썸네일 ===== -->
        <div class="col-md-3">
          <h6 class="fw-bold mb-3">첨부 이미지</h6>
          <div class="d-flex flex-column gap-2">
            <div v-for="(img, idx) in previewImages" :key="idx" class="position-relative">
              <img :src="img" class="img-thumbnail w-100" style="max-height:120px; object-fit:cover;" />
              <button type="button" class="btn btn-sm btn-danger position-absolute top-0 end-0 m-1 rounded-circle"
                @click="removeImage(idx)">
                ✕
              </button>
            </div>

            <div v-if="!previewImages.length" class="text-muted small">
              아직 선택된 이미지가 없습니다.
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed, onMounted, ref } from "vue";
import { useStore } from "vuex";
import { useRouter } from "vue-router";
import postApi from "@/apis/postApi";

const store = useStore();
const router = useRouter();

/* ========================
  작성 상태
======================== */
const title = ref("");
const content = ref("");
const isRequest = ref(false);
const user = JSON.parse(localStorage.getItem("user") || "{}");
const userId = user.userId || null;

// 초기 로딩
onMounted(async () => {
  const res = await postApi.getTagList();
  tags.value = res.data.tags || [];
});

/* ========================
  태그
======================== */
// 전체 태그 목록(이름→id 매핑용)
const tags = ref([]);

const selectedTags = ref([]); // tagId만 담김
const topTags = computed(() => tags.value.slice(0, 5));  // 첫 5개
const moreTags = computed(() => tags.value.slice(5));
const showMore = ref(false);

function toggleTag(tagName) {
  const idx = selectedTags.value.indexOf(tagName);
  if (idx >= 0) selectedTags.value.splice(idx, 1);
  else selectedTags.value.push(tagName);
}
function removeTag(tagName) {
  const idx = selectedTags.value.indexOf(tagName);
  if (idx >= 0) selectedTags.value.splice(idx, 1);
}
function toggleMore() {
  showMore.value = !showMore.value;
}


/* ========================
  이미지
======================== */
const previewImages = ref([]);
const files = ref([]);
const previewImage = ref(null);
const submitting = ref(false);

function onFileChange(e) {
  const picked = Array.from(e.target.files || []);
  for (const file of picked) {
    if (files.value.length >= 10) break;
    files.value.push(file);

    const reader = new FileReader();
    reader.onload = (ev) => {
      previewImages.value.push(ev.target.result);
      if (!previewImage.value) previewImage.value = ev.target.result;
    };
    reader.readAsDataURL(file);
  }
  e.target.value = "";
}

function removeImage(idx) {
  files.value.splice(idx, 1);
  previewImages.value.splice(idx, 1);
  previewImage.value = previewImages.value[0] || null;
}

/* ========================
  작성한 내용 제출
======================== */
async function submitPost() {
  if (!title.value.trim() || !content.value.trim()) return;
  submitting.value = true;
  try {
    const post = {
      postTitle: title.value,
      postContent: content.value,
      isRequest: isRequest.value ? "Y" : "N",
      postUserId: userId,
      postAttaches: files.value   // 첨부 이미지 배열
    };

    const created = await store.dispatch("post/create", post);
    const newId = created?.postId;
    if (!newId) return;

    if (selectedTags.value.length) {
      await store.dispatch("post/addTags", { 
        postId: newId, tagIds: selectedTags.value 
      });
    }

    router.push(`/post/${newId}`);
  } catch (e) {
    console.error(e);
  } finally {
    submitting.value = false;
  }
}

</script>
