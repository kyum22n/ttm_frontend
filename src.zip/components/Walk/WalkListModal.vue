<template>
  <div v-if="modelValue" class="modal-backdrop" @click.self="close">
    <div class="modal-card">
      <div class="modal-header">
        <h5 class="m-0">산책 신청 내역</h5>
        <button type="button" class="btn-close" @click="close"></button>
      </div>

      <div class="modal-body">
        <!-- 탭 -->
        <ul class="nav nav-tabs mb-3">
          <li class="nav-item">
            <button class="nav-link" :class="{ active: tab==='received' }" @click="tab='received'">받은 신청</button>
          </li>
          <li class="nav-item">
            <button class="nav-link" :class="{ active: tab==='sent' }" @click="tab='sent'">내가 신청</button>
          </li>
          <li class="nav-item">
            <button class="nav-link" :class="{ active: tab==='group' }" @click="tab='group'">그룹 신청</button>
          </li>
        </ul>

        <!-- 로딩 -->
        <div v-if="loading" class="text-center text-muted py-4">불러오는 중...</div>

        <!-- 받은 신청 -->
        <div v-else-if="tab==='received'">
          <div v-if="received.length === 0" class="text-center text-muted py-4">받은 신청이 없습니다.</div>
          <ul v-else class="list-group">
            <li
              v-for="w in received"
              :key="w.requestOneId"
              class="list-group-item d-flex justify-content-between"
            >
              <div>
                <div class="fw-bold">신청자: {{ w.requestUserId }}</div>
                <div class="small text-muted">
                  상태: {{ statusLabel(w.rstatus) }} · 신청일: {{ fmt(w.createdAt) }}
                </div>
              </div>
              <i class="bi bi-arrow-down-left-circle"></i>
            </li>
          </ul>
        </div>

        <!-- 내가 신청 -->
        <div v-else-if="tab==='sent'">
          <div v-if="sent.length === 0" class="text-center text-muted py-4">내가 신청한 내역이 없습니다.</div>
          <ul v-else class="list-group">
            <li
              v-for="w in sent"
              :key="w.requestOneId"
              class="list-group-item d-flex justify-content-between"
            >
              <div>
                <div class="fw-bold">수락자: {{ w.receiveUserId }}</div>
                <div class="small text-muted">
                  상태: {{ statusLabel(w.rstatus) }} · 신청일: {{ fmt(w.createdAt) }}
                </div>
              </div>
              <i class="bi bi-arrow-up-right-circle"></i>
            </li>
          </ul>
        </div>

        <!-- 그룹 신청 -->
        <div v-else>
          <div v-if="groups.length === 0" class="text-center text-muted py-4">그룹 산책 신청이 없습니다.</div>
          <ul v-else class="list-group">
            <li
              v-for="g in groups"
              :key="g.requestId ?? g.postId"
              class="list-group-item d-flex justify-content-between"
            >
              <div>
                <div class="fw-bold">그룹글: {{ g.postId ?? '-' }}</div>
                <div class="small text-muted">신청일: {{ fmt(g.createdAt) }}</div>
              </div>
              <i class="bi bi-people"></i>
            </li>
          </ul>
        </div>
      </div>

      <div class="modal-footer">
        <button class="btn btn-secondary" @click="close">닫기</button>
      </div>
    </div>
  </div>
</template>

<script setup>
/* eslint-disable */
import { ref, watch } from "vue";
import { useStore } from "vuex";
import walkApi from "@/apis/walkApi";

const props = defineProps({
  modelValue: { type: Boolean, default: false },
});
const emit = defineEmits(["update:modelValue"]);

const store = useStore();

const tab = ref("received");
const loading = ref(false);
const received = ref([]);
const sent = ref([]);
const groups = ref([]);

function close() {
  emit("update:modelValue", false);
}
function fmt(iso) {
  return iso ? new Date(iso).toLocaleString() : "";
}
function statusLabel(s) {
  switch ((s || "P").toUpperCase()) {
    case "A":
      return "승인";
    case "R":
      return "거절";
    default:
      return "대기";
  }
}

async function loadAll() {
  const me = store.state.user?.userId;
  if (!me) {
    received.value = [];
    sent.value = [];
    groups.value = [];
    return;
  }
  loading.value = true;
  try {
    const [rec, sen, grp] = await Promise.allSettled([
      walkApi.getReceivedRequests(me),
      walkApi.getOneOnOneRequests(me),
      walkApi.getGroupRequests(me),
    ]);

    received.value =
      rec.status === "fulfilled" ? rec.value?.data?.walkReceiveList || [] : [];
    sent.value =
      sen.status === "fulfilled" ? sen.value?.data?.walkRequestList || [] : [];
    groups.value =
      grp.status === "fulfilled"
        ? Array.isArray(grp.value?.data?.list)
          ? grp.value.data.list
          : Array.isArray(grp.value?.data)
          ? grp.value.data
          : []
        : [];
  } finally {
    loading.value = false;
  }
}

// 모달이 열릴 때마다 로드
watch(
  () => props.modelValue,
  (v) => {
    if (v) {
      tab.value = "received";
      loadAll();
    }
  }
);
</script>

<style scoped>
.modal-backdrop {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.5);
  display: grid;
  place-items: center;
  z-index: 2000;
}
.modal-card {
  width: min(720px, 92vw);
  background: #fff;
  border-radius: 0.5rem;
  overflow: hidden;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
}
.modal-header,
.modal-footer {
  padding: 0.75rem 1rem;
  background: #f8f9fa;
}
.modal-body {
  padding: 1rem;
  max-height: 70vh;
  overflow: auto;
}
</style>
