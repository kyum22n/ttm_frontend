<template>
  <div><login /></div>
</template>

<script setup>
import Login from "@/views/Auth/Login";
</script>
