<template>
    <div class="wrap">
        <h2 class="title">채팅 요청 대기</h2>

        <p class="desc">방 번호: <b>{{ roomId }}</b></p>
        <p v-if="info">상태: <b>{{ info.chatroomStatus }}</b> · 요청자: <b>{{ info.requestedBy }}</b></p>

        <div class="actions">
            <button class="btn" :disabled="loading || !canDecide" @click="approve">승인</button>
            <button class="btn danger" :disabled="loading || !canDecide" @click="reject">거절</button>
        </div>

        <p v-if="!canDecide" class="hint">
            요청을 보낸 사용자(요청자)는 승인/거절할 수 없습니다.
        </p>
    </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'

const BASE =
    (import.meta?.env?.VITE_API_BASE) ||
    process.env.VUE_APP_API_BASE ||
    'http://localhost:8080'

// TODO: 로그인 값으로 교체
const me = 1

const roomId = Number(new URLSearchParams(location.search).get('roomId') || 0)
const loading = ref(false)
const info = ref(null) // 방 정보 (requestedBy, status 등)

async function getJSON(url) {
    const res = await fetch(url)
    if (!res.ok) throw res
    return res.json()
}

const canDecide = computed(() => {
    if (!info.value) return false
    // 요청받은 사람(= requestedBy가 아닌 사람)만 승인/거절 가능
    return me === info.value.chatuser1Id || me === info.value.chatuser2Id
        ? me !== info.value.requestedBy
        : false
})

async function loadInfo() {
    try {
        // info API에서 P면 403을 줄 수도 있으니, 여기선 /chat/rooms/{id}를 직접 하나 더 만들지
        // 않았다면 아래처럼 try로 감싸고 본문에서 room만 뽑아옵니다.
        const data = await getJSON(`${BASE}/chat/rooms/${roomId}/info?userId=${me}`)
        info.value = data.room
        // 이미 승인됐다면 바로 상세로
        if (data.canChat) {
            location.href = `/message/detail?roomId=${roomId}`
        }
    } catch (e) {
        // 403/404여도 body에 room이 없을 수 있음 → 버튼만 막고 남겨둠
        try {
            const body = await e.json()
            if (body?.room) info.value = body.room
        } catch (_) {
            // 무시하기!
            void 0;
        }
    }
}

async function approve() {
    if (!canDecide.value) return
    loading.value = true
    try {
        await fetch(`${BASE}/chat/rooms/${roomId}/approve?by=${me}`, { method: 'PUT' })
        // 승인되면 방으로 이동
        location.href = `/message/detail?roomId=${roomId}`
    } finally {
        loading.value = false
    }
}

async function reject() {
    if (!canDecide.value) return
    loading.value = true
    try {
        await fetch(`${BASE}/chat/rooms/${roomId}/reject?by=${me}`, { method: 'PUT' })
        alert('요청을 거절했어요.')
        // 목록 등 원하는 경로로 이동
        location.href = '/message'
    } finally {
        loading.value = false
    }
}

onMounted(loadInfo)
</script>

<style scoped>
.wrap {
    max-width: 720px;
    margin: 40px auto;
    padding: 24px;
    border: 1px solid #ddd;
    border-radius: 12px;
    background: #fff;
}

.title {
    margin: 0 0 12px;
}

.desc {
    color: #555;
}

.actions {
    display: flex;
    gap: 8px;
    margin: 16px 0;
}

.btn {
    padding: 10px 16px;
    border: 1px solid #888;
    border-radius: 8px;
    background: #fff;
    cursor: pointer;
}

.btn:disabled {
    opacity: .5;
    cursor: not-allowed;
}

.btn.danger {
    border-color: #d33;
    color: #d33;
}

.hint {
    color: #777;
    font-size: .9rem;
}
</style>
